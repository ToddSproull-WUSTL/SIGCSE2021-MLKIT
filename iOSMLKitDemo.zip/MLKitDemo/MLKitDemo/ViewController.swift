//
//  ViewController.swift
//  MLKitDemo
//
//  Created by Todd Sproull on 3/7/21.
//  Copyright © 2021 Todd Sproull. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var currentImage = 0
     let totalImages = 5
     
     @IBOutlet weak var theSpinner: UIActivityIndicatorView!
     @IBOutlet weak var theImage: UIImageView!
     @IBOutlet weak var theLog: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
           updateImage()
        
    }

    @IBAction func textRecognition(_ sender: Any) {
        print("in text recognition")
    }
 
    @IBAction func imageLabeling(_ sender: Any) {
         print("in image labeling")
    }
     
    @IBAction func faceDetection(_ sender: Any) {
        print("in face detection")
    }
    
 
    func updateImage(){
        let imageToDisplay = "\(currentImage).png"
        theImage.image = UIImage.init(named: imageToDisplay)
        theLog.text = ""
    }
    
    @IBAction func nextImage(_ sender: Any) {
        currentImage += 1
        if(currentImage >= totalImages) {
            currentImage = 0
        }
        updateImage()
    }
    
    @IBAction func previousImage(_ sender: Any) {
        currentImage -= 1
        if(currentImage < 0) {
            currentImage = totalImages - 1
        }
        updateImage()
    }
    
    private func transformMatrix() -> CGAffineTransform {
      guard let image = theImage.image else { return CGAffineTransform() }
      let imageViewWidth = theImage.frame.size.width
      let imageViewHeight = theImage.frame.size.height
      let imageWidth = image.size.width
      let imageHeight = image.size.height

      let imageViewAspectRatio = imageViewWidth / imageViewHeight
      let imageAspectRatio = imageWidth / imageHeight
      let scale =
        (imageViewAspectRatio > imageAspectRatio)
        ? imageViewHeight / imageHeight : imageViewWidth / imageWidth

      // Image view's `contentMode` is `scaleAspectFit`, which scales the image to fit the size of the
      // image view by maintaining the aspect ratio. Multiple by `scale` to get image's original size.
      let scaledImageWidth = imageWidth * scale
      let scaledImageHeight = imageHeight * scale
      let xValue = (imageViewWidth - scaledImageWidth) / CGFloat(2.0)
      let yValue = (imageViewHeight - scaledImageHeight) / CGFloat(2.0)

      var transform = CGAffineTransform.identity.translatedBy(x: xValue, y: yValue)
      transform = transform.scaledBy(x: scale, y: scale)
      return transform
    }

}

private enum Constants {
  static let smallDotRadius: CGFloat = 5.0
}
